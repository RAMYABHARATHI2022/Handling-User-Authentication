package com.example.Authentication.entities;

public @interface Id {

}
