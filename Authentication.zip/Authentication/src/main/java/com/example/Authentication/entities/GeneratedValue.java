package com.example.Authentication.entities;

public @interface GeneratedValue {

	String strategy();

}
