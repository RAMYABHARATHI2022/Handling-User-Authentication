package com.example.Authentication.entities;

public interface GenerationType {

	String IDENTITY = null;

}
