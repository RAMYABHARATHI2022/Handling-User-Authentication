package javax.persistence;

public class GenerationType {

}
